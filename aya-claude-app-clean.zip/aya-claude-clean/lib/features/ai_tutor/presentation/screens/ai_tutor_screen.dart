import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AiTutorScreen extends ConsumerStatefulWidget {
  const AiTutorScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<AiTutorScreen> createState() => _AiTutorScreenState();
}

class _AiTutorScreenState extends ConsumerState<AiTutorScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [
    ChatMessage(
      text: 'Salut! Je suis Miss AYA, ton tuteur IA. Comment puis-je t\'aider avec l\'Arabe, le Coran ou l\'Islam?',
      isAI: true,
      timestamp: DateTime.now(),
    ),
  ];
  bool _isLoading = false;

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  void _sendMessage() async {
    if (_messageController.text.isEmpty) return;

    final userMessage = _messageController.text;
    _messageController.clear();

    setState(() {
      _messages.add(ChatMessage(
        text: userMessage,
        isAI: false,
        timestamp: DateTime.now(),
      ));
      _isLoading = true;
    });

    // Simulate AI response
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _messages.add(ChatMessage(
        text: _generateAIResponse(userMessage),
        isAI: true,
        timestamp: DateTime.now(),
      ));
      _isLoading = false;
    });
  }

  String _generateAIResponse(String userMessage) {
    final lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.contains('arabe')) {
      return 'L\'Arabe (العربية) est une belle langue! Elle a 28 lettres et s\'écrit de droite à gauche. Veux-tu apprendre l\'alphabet ou le vocabulaire?';
    } else if (lowerMessage.contains('coran')) {
      return 'Le Coran est notre guide éternel! Il contient 114 sourates et 6236 versets. Quelle sourate veux-tu étudier?';
    } else if (lowerMessage.contains('hadith')) {
      return 'Les hadiths nous enseignent comment le Prophète Muhammad (paix soit sur lui) a vécu. Veux-tu en savoir plus?';
    } else if (lowerMessage.contains('quiz')) {
      return 'D\'accord! Créons un quiz pour toi. Quel sujet: l\'Arabe, le Coran ou l\'Islam?';
    } else {
      return 'C\'est une bonne question! Peux-tu m\'en dire plus sur ce sujet? Je suis spécialisée en Arabe, Coran et Sciences Islamiques.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tuteur IA (Miss AYA)'),
        elevation: 0,
        actions: [
          PopupMenuButton(
            itemBuilder: (context) => [
              const PopupMenuItem(
                child: Text('Générer Quiz'),
              ),
              const PopupMenuItem(
                child: Text('Nouvelle Conversation'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Messages List
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              reverse: true,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[_messages.length - 1 - index];
                return _ChatBubble(message: message);
              },
            ),
          ),

          // Loading Indicator
          if (_isLoading)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Miss AYA pense...',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            ),

          // Input Area
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                top: BorderSide(color: Colors.grey[200]!),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: 'Posez votre question...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide(color: Colors.grey[300]!),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.emoji_emotions_outlined),
                        onPressed: () {},
                      ),
                    ),
                    enabled: !_isLoading,
                  ),
                ),
                const SizedBox(width: 8),
                FloatingActionButton(
                  onPressed: _isLoading ? null : _sendMessage,
                  backgroundColor: const Color(0xFF2E7D32),
                  child: const Icon(Icons.send),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isAI;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isAI,
    required this.timestamp,
  });
}

class _ChatBubble extends StatelessWidget {
  final ChatMessage message;

  const _ChatBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Align(
        alignment: message.isAI ? Alignment.centerLeft : Alignment.centerRight,
        child: Container(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.75,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: message.isAI
                ? Colors.grey[200]
                : const Color(0xFF2E7D32),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: message.isAI
                ? CrossAxisAlignment.start
                : CrossAxisAlignment.end,
            children: [
              if (message.isAI)
                const Padding(
                  padding: EdgeInsets.only(bottom: 4),
                  child: Text(
                    '🤖 Miss AYA',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
              Text(
                message.text,
                style: TextStyle(
                  color: message.isAI ? Colors.black : Colors.white,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${message.timestamp.hour}:${message.timestamp.minute.toString().padLeft(2, '0')}',
                style: TextStyle(
                  fontSize: 10,
                  color: message.isAI ? Colors.grey[600] : Colors.white70,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
