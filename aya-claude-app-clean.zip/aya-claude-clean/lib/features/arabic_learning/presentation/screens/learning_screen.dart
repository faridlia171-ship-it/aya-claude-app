import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class LearningScreen extends StatefulWidget {
  const LearningScreen({Key? key}) : super(key: key);

  @override
  State<LearningScreen> createState() => _LearningScreenState();
}

class _LearningScreenState extends State<LearningScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Apprendre l\'Arabe'),
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Alphabet'),
            Tab(text: 'Vocabulaire'),
            Tab(text: 'Grammaire'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _AlphabetTab(),
          _VocabularyTab(),
          _GrammarTab(),
        ],
      ),
    );
  }
}

class _AlphabetTab extends StatelessWidget {
  final letters = [
    {'letter': 'ا', 'name': 'Alef', 'example': 'أسد (lion)'},
    {'letter': 'ب', 'name': 'Ba', 'example': 'بيت (maison)'},
    {'letter': 'ت', 'name': 'Ta', 'example': 'تمر (datte)'},
    {'letter': 'ث', 'name': 'Tha', 'example': 'ثلج (neige)'},
    {'letter': 'ج', 'name': 'Jim', 'example': 'جمل (chameau)'},
    {'letter': 'ح', 'name': 'Ha', 'example': 'حرف (lettre)'},
    {'letter': 'خ', 'name': 'Kha', 'example': 'خيل (chevaux)'},
    {'letter': 'د', 'name': 'Dal', 'example': 'دار (maison)'},
  ];

  _AlphabetTab();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Alphabet Arabe (Abjad)',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'L\'alphabet arabe compte 28 lettres. Cliquez sur chaque lettre pour l\'entendre.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              childAspectRatio: 1,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
            ),
            itemCount: letters.length,
            itemBuilder: (context, index) {
              final letter = letters[index];
              return _LetterCard(
                letter: letter['letter']!,
                name: letter['name']!,
                example: letter['example']!,
              );
            },
          ),
        ],
      ),
    );
  }
}

class _VocabularyTab extends StatelessWidget {
  final categories = [
    {'title': 'Famille', 'icon': '👨‍👩‍👧‍👦'},
    {'title': 'Aliments', 'icon': '🍎'},
    {'title': 'Nombres', 'icon': '🔢'},
    {'title': 'Verbes Courants', 'icon': '⚡'},
    {'title': 'Adjectifs', 'icon': '✨'},
    {'title': 'Corps Humain', 'icon': '🫀'},
  ];

  _VocabularyTab();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Vocabulaire Thématique',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          ...categories.map((cat) {
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: Text(cat['icon']!, style: const TextStyle(fontSize: 24)),
                title: Text(cat['title']!),
                trailing: const Icon(Icons.arrow_forward),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${cat['title']} - Bientôt disponible')),
                  );
                },
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}

class _GrammarTab extends StatelessWidget {
  _GrammarTab();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Fondamentals de Grammaire',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          _GrammarRule(
            title: 'Genre (Masculin/Féminin)',
            description: 'En arabe, tous les noms ont un genre. Le féminin est souvent marqué par ة (ta marbuta).',
            example: 'محمد (Muhamad - masc.) vs فاطمة (Fatima - fem.)',
          ),
          const SizedBox(height: 12),
          _GrammarRule(
            title: 'Nombre (Singulier/Pluriel)',
            description: 'Le pluriel peut être régulier (avec suffixes) ou irrégulier.',
            example: 'كتاب (livre) → كتب (livres)',
          ),
          const SizedBox(height: 12),
          _GrammarRule(
            title: 'Cas Grammaticaux',
            description: 'L\'arabe a 3 cas: Nominatif (الرفع), Accusatif (النصب), Génitif (الجر).',
            example: 'الكتاب (le livre - nominatif) vs الكتاب (à le livre - génitif)',
          ),
          const SizedBox(height: 12),
          _GrammarRule(
            title: 'Verbes Réguliers',
            description: 'Les verbes réguliers suivent un schème prévisible.',
            example: 'كتب (il a écrit) - الجذر: ك-ت-ب',
          ),
        ],
      ),
    );
  }
}

class _LetterCard extends StatelessWidget {
  final String letter;
  final String name;
  final String example;

  const _LetterCard({
    required this.letter,
    required this.name,
    required this.example,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('الحرف: $letter'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('الاسم: $name'),
                const SizedBox(height: 8),
                Text('مثال: $example'),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('إغلاق'),
              ),
            ],
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF2E7D32).withOpacity(0.1),
          border: Border.all(color: const Color(0xFF2E7D32), width: 2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              letter,
              style: const TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              name,
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class _GrammarRule extends StatelessWidget {
  final String title;
  final String description;
  final String example;

  const _GrammarRule({
    required this.title,
    required this.description,
    required this.example,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            description,
            style: const TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.05),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              example,
              style: const TextStyle(
                fontSize: 11,
                fontStyle: FontStyle.italic,
                color: Colors.blue,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
