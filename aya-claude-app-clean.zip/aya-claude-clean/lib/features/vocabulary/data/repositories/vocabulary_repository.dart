import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';

class VocabularyRepository {
  final Database database;

  VocabularyRepository({required this.database});

  // ============= LOAD VOCABULARY DATA =============

  /// Charger le vocabulaire depuis les assets
  Future<void> loadVocabularyFromAssets() async {
    try {
      // Vérifier si déjà chargé
      final count = await database.rawQuery(
        'SELECT COUNT(*) as count FROM vocabulary_sets',
      );
      
      if ((count.first['count'] as int) > 0) {
        print('✅ Vocabulaire déjà chargé');
        return;
      }

      print('📚 Chargement du vocabulaire arabe...');

      // Charger JSON depuis assets
      final jsonString = await rootBundle.loadString(
        'assets/vocabulary/vocabulary.json',
      );
      
      final vocabData = json.decode(jsonString) as Map<String, dynamic>;
      final sets = vocabData['vocabulary_sets'] as List;

      for (var set in sets) {
        // Insérer l'ensemble de vocabulaire
        final setResult = await database.insert(
          'vocabulary_sets',
          {
            'category': set['category'] ?? 'General',
            'level': set['level'] ?? 'beginner',
            'description': set['description'] ?? '',
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );

        // Insérer les mots
        final words = set['words'] as List? ?? [];
        for (var word in words) {
          await database.insert(
            'vocabulary_words',
            {
              'set_id': setResult,
              'arabic_word': word['arabic'] ?? '',
              'transliteration': word['transliteration'] ?? '',
              'english': word['english'] ?? '',
              'french': word['french'] ?? '',
              'example_arabic': word['example'] ?? '',
              'example_english': word['example_meaning'] ?? '',
              'audio_url': word['audio_url'] ?? '',
            },
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }

      print('✅ Vocabulaire chargé: ${sets.length} catégories');
    } catch (e) {
      print('❌ Erreur lors du chargement du vocabulaire: $e');
      rethrow;
    }
  }

  /// Charger l'alphabet arabe
  Future<void> loadAlphabetFromAssets() async {
    try {
      final count = await database.rawQuery(
        'SELECT COUNT(*) as count FROM alphabet_letters',
      );
      
      if ((count.first['count'] as int) > 0) {
        print('✅ Alphabet déjà chargé');
        return;
      }

      print('🔤 Chargement de l\'alphabet arabe...');

      // Charger JSON
      final jsonString = await rootBundle.loadString(
        'assets/vocabulary/alphabet.json',
      );
      
      final alphabetData = json.decode(jsonString) as Map<String, dynamic>;
      final letters = alphabetData['alphabet'] as List;

      for (var letter in letters) {
        await database.insert(
          'alphabet_letters',
          {
            'letter_number': letter['number'] ?? 0,
            'arabic_letter': letter['letter'] ?? '',
            'transliteration': letter['transliteration'] ?? '',
            'english_name': letter['english_name'] ?? '',
            'french_name': letter['french_name'] ?? '',
            'audio_url': letter['audio_url'] ?? '',
            'example_word': letter['example_word'] ?? '',
            'example_meaning': letter['example_meaning'] ?? '',
            'isolated_form': letter['isolated_form'] ?? '',
            'initial_form': letter['initial_form'] ?? '',
            'medial_form': letter['medial_form'] ?? '',
            'final_form': letter['final_form'] ?? '',
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      print('✅ Alphabet chargé: ${letters.length} lettres');
    } catch (e) {
      print('⚠️  Alphabet non trouvé: $e');
    }
  }

  // ============= QUERIES =============

  /// Récupérer tous les ensembles de vocabulaire
  Future<List<Map<String, dynamic>>> getVocabularySets() async {
    try {
      return await database.query('vocabulary_sets');
    } catch (e) {
      print('❌ Erreur getVocabularySets: $e');
      rethrow;
    }
  }

  /// Récupérer les mots d'un ensemble
  Future<List<Map<String, dynamic>>> getWordsBySet(
    int setId, {
    int limit = 50,
  }) async {
    try {
      return await database.query(
        'vocabulary_words',
        where: 'set_id = ?',
        whereArgs: [setId],
        limit: limit,
      );
    } catch (e) {
      print('❌ Erreur getWordsBySet: $e');
      rethrow;
    }
  }

  /// Récupérer l'alphabet complet
  Future<List<Map<String, dynamic>>> getAlphabet() async {
    try {
      return await database.query(
        'alphabet_letters',
        orderBy: 'letter_number ASC',
      );
    } catch (e) {
      print('❌ Erreur getAlphabet: $e');
      rethrow;
    }
  }

  /// Récupérer une lettre spécifique
  Future<Map<String, dynamic>?> getLetter(int letterNumber) async {
    try {
      final result = await database.query(
        'alphabet_letters',
        where: 'letter_number = ?',
        whereArgs: [letterNumber],
      );
      return result.isNotEmpty ? result.first : null;
    } catch (e) {
      print('❌ Erreur getLetter: $e');
      rethrow;
    }
  }

  /// Rechercher un mot
  Future<List<Map<String, dynamic>>> searchWords(String query) async {
    try {
      return await database.query(
        'vocabulary_words',
        where: 'arabic_word LIKE ? OR english LIKE ? OR french LIKE ?',
        whereArgs: ['%$query%', '%$query%', '%$query%'],
      );
    } catch (e) {
      print('❌ Erreur searchWords: $e');
      rethrow;
    }
  }

  /// Ajouter un mot aux favoris
  Future<void> addWordBookmark(int wordId, String word) async {
    try {
      await database.insert(
        'bookmarks',
        {
          'user_id': 'default_user',
          'content_type': 'vocabulary',
          'content_id': wordId.toString(),
          'title': 'Word: $word',
          'created_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
      print('✅ Mot $word ajouté aux favoris');
    } catch (e) {
      print('❌ Erreur addWordBookmark: $e');
    }
  }

  /// Statistiques vocabulaire
  Future<Map<String, dynamic>> getVocabularyStats() async {
    try {
      final setsCount = await database.rawQuery(
        'SELECT COUNT(*) as count FROM vocabulary_sets',
      );
      
      final wordsCount = await database.rawQuery(
        'SELECT COUNT(*) as count FROM vocabulary_words',
      );

      final lettersCount = await database.rawQuery(
        'SELECT COUNT(*) as count FROM alphabet_letters',
      );

      return {
        'vocabulary_sets': (setsCount.first['count'] as int),
        'words': (wordsCount.first['count'] as int),
        'alphabet_letters': (lettersCount.first['count'] as int),
      };
    } catch (e) {
      print('❌ Erreur getVocabularyStats: $e');
      rethrow;
    }
  }
}
