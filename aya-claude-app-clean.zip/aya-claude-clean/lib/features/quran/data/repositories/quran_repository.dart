import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';

class QuranRepository {
  final Database database;

  QuranRepository({required this.database});

  // ============= LOAD QURAN DATA =============

  /// Charger le Coran complet depuis le fichier JSON aux assets
  /// Exécuter une seule fois au démarrage
  Future<void> loadQuranFromAssets() async {
    try {
      // Vérifier si déjà chargé
      final count = await database.rawQuery(
        'SELECT COUNT(*) as count FROM quran_surahs',
      );
      
      if ((count.first['count'] as int) > 0) {
        print('✅ Coran déjà chargé dans la base de données');
        return;
      }

      print('📖 Chargement du Coran depuis les assets...');

      // Charger JSON depuis assets
      final jsonString = await rootBundle.loadString(
        'assets/quran/quran-uthmani.json',
      );
      
      final quranData = json.decode(jsonString) as Map<String, dynamic>;
      final surahs = quranData['surahs'] as List;

      // Insérer toutes les sourates et versets
      for (var surah in surahs) {
        // Insérer la sourate
        await database.insert(
          'quran_surahs',
          {
            'number': surah['number'],
            'name_arabic': surah['name'] ?? 'Unknown',
            'name_transliteration': surah['englishName'] ?? '',
            'name_english': surah['englishNameTranslation'] ?? '',
            'revelation_type': surah['revelationType'] ?? 'Unknown',
            'verse_count': surah['numberOfAyahs'],
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );

        // Insérer les versets
        final ayahs = surah['ayahs'] as List;
        for (var ayah in ayahs) {
          await database.insert(
            'quran_verses',
            {
              'surah_id': surah['number'],
              'verse_number': ayah['numberInSurah'],
              'arabic_text': ayah['text'] ?? '',
              'transliteration': '',
              'french_translation': '', // À remplir avec API externe
              'english_translation': '',
              'audio_url': '',
            },
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }

      print('✅ Coran chargé avec succès! ${surahs.length} sourates');
    } catch (e) {
      print('❌ Erreur lors du chargement du Coran: $e');
      rethrow;
    }
  }

  // ============= QUERIES =============

  /// Récupérer toutes les sourates
  Future<List<Map<String, dynamic>>> getAllSurahs() async {
    try {
      return await database.query(
        'quran_surahs',
        orderBy: 'number ASC',
      );
    } catch (e) {
      print('❌ Erreur getAllSurahs: $e');
      rethrow;
    }
  }

  /// Récupérer une sourate spécifique
  Future<Map<String, dynamic>?> getSurah(int surahNumber) async {
    try {
      final result = await database.query(
        'quran_surahs',
        where: 'number = ?',
        whereArgs: [surahNumber],
      );
      return result.isNotEmpty ? result.first : null;
    } catch (e) {
      print('❌ Erreur getSurah: $e');
      rethrow;
    }
  }

  /// Récupérer tous les versets d'une sourate
  Future<List<Map<String, dynamic>>> getVersesBySurah(int surahNumber) async {
    try {
      return await database.query(
        'quran_verses',
        where: 'surah_id = ?',
        whereArgs: [surahNumber],
        orderBy: 'verse_number ASC',
      );
    } catch (e) {
      print('❌ Erreur getVersesBySurah: $e');
      rethrow;
    }
  }

  /// Rechercher des versets par texte
  Future<List<Map<String, dynamic>>> searchVerses(String query) async {
    try {
      return await database.query(
        'quran_verses',
        where: 'arabic_text LIKE ? OR french_translation LIKE ?',
        whereArgs: ['%$query%', '%$query%'],
      );
    } catch (e) {
      print('❌ Erreur searchVerses: $e');
      rethrow;
    }
  }

  /// Ajouter un verset aux favoris
  Future<void> addBookmark(int surahNumber, int verseNumber) async {
    try {
      await database.insert(
        'bookmarks',
        {
          'user_id': 'default_user', // À remplacer par vrai user_id
          'content_type': 'verse',
          'content_id': '$surahNumber:$verseNumber',
          'title': 'Surah $surahNumber Verse $verseNumber',
          'created_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
      print('✅ Verset ${surahNumber}:${verseNumber} ajouté aux favoris');
    } catch (e) {
      print('❌ Erreur addBookmark: $e');
    }
  }

  /// Récupérer les favoris
  Future<List<Map<String, dynamic>>> getBookmarks() async {
    try {
      return await database.query(
        'bookmarks',
        where: 'user_id = ?',
        whereArgs: ['default_user'],
        orderBy: 'created_at DESC',
      );
    } catch (e) {
      print('❌ Erreur getBookmarks: $e');
      rethrow;
    }
  }

  /// Charger traductions français depuis API externe
  Future<void> loadFrenchTranslations() async {
    try {
      print('📚 Chargement des traductions françaises...');
      
      // Exemple: Charger depuis Hamidullah via API
      // À implémenter selon l'API choisie
      // https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/fra-hamidullah.json
      
      final jsonString = await rootBundle.loadString(
        'assets/quran/quran-fr-hamidullah.json',
      );
      
      final translationData = json.decode(jsonString) as Map<String, dynamic>;
      final surahs = translationData['surahs'] as List;

      for (var surah in surahs) {
        final ayahs = surah['ayahs'] as List;
        for (var ayah in ayahs) {
          await database.update(
            'quran_verses',
            {
              'french_translation': ayah['text'] ?? '',
            },
            where: 'surah_id = ? AND verse_number = ?',
            whereArgs: [surah['number'], ayah['numberInSurah']],
          );
        }
      }

      print('✅ Traductions françaises chargées');
    } catch (e) {
      print('⚠️  Traductions françaises non disponibles: $e');
    }
  }
}
