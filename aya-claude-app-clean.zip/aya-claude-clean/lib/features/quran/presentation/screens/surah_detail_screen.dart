import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SurahDetailScreen extends StatelessWidget {
  final String surahId;

  const SurahDetailScreen({
    Key? key,
    required this.surahId,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Sample surah data
    final surahData = {
      'name': 'الفاتحة (Al-Fatiha)',
      'number': 1,
      'verseCount': 7,
      'revelationType': 'Meccan',
      'verses': [
        {
          'number': 1,
          'arabic': 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
          'transliteration': 'Bismillah ar-Rahman ar-Rahim',
          'french': 'Au nom d\'Allah, le Très Miséricordieux, le Miséricordieux',
        },
        {
          'number': 2,
          'arabic': 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
          'transliteration': 'Alhamdulillahi rabbil alamin',
          'french': 'Louange à Allah, Seigneur de l\'Univers',
        },
        {
          'number': 3,
          'arabic': 'الرَّحْمَٰنِ الرَّحِيمِ',
          'transliteration': 'Ar-Rahman ar-Rahim',
          'french': 'Le Très Miséricordieux, le Miséricordieux',
        },
        {
          'number': 4,
          'arabic': 'مَالِكِ يَوْمِ الدِّينِ',
          'transliteration': 'Maliki yawmid-din',
          'french': 'Maître du Jour de la Rétribution',
        },
        {
          'number': 5,
          'arabic': 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
          'transliteration': 'Iyyaka na\'budu wa iyyaka nasta\'in',
          'french': 'C\'est Toi que nous adorons et c\'est Toi dont nous implorons secours',
        },
        {
          'number': 6,
          'arabic': 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
          'transliteration': 'Ihdinas-sirat-al-mustaqim',
          'french': 'Dirige-nous sur le chemin droit',
        },
        {
          'number': 7,
          'arabic': 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
          'transliteration': 'Sirat-allatheena an\'amta \'alayhim ghayril-maghdoobi \'alayhim wa lad-daallin',
          'french': 'Le chemin de ceux que Tu as comblés de faveurs, non pas de ceux qui ont encouru Ton courroux, ni des égarés',
        },
      ],
    };

    return Scaffold(
      appBar: AppBar(
        title: Text(surahData['name'] as String),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.bookmark_outline),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Ajouté aux favoris')),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Info
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF2E7D32).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFF2E7D32),
                  width: 2,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Sourate ${surahData['number']}',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF2E7D32),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${surahData['verseCount']} versets',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        surahData['revelationType'] as String,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Verses
            const Text(
              'Versets',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ...(surahData['verses'] as List).map((verse) {
              return _VerseCard(
                number: verse['number'],
                arabic: verse['arabic'],
                transliteration: verse['transliteration'],
                french: verse['french'],
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}

class _VerseCard extends StatefulWidget {
  final int number;
  final String arabic;
  final String transliteration;
  final String french;

  const _VerseCard({
    required this.number,
    required this.arabic,
    required this.transliteration,
    required this.french,
  });

  @override
  State<_VerseCard> createState() => _VerseCardState();
}

class _VerseCardState extends State<_VerseCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Arabic text
                  Text(
                    widget.arabic,
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      height: 1.8,
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Verse number and expansion toggle
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Verset ${widget.number}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                      Icon(
                        _expanded ? Icons.expand_less : Icons.expand_more,
                        color: const Color(0xFF2E7D32),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (_expanded)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                border: Border(
                  top: BorderSide(color: Colors.grey[300]!),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Translittération:',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2E7D32),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    widget.transliteration,
                    style: const TextStyle(fontSize: 12),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Traduction (Français):',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2E7D32),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    widget.french,
                    style: const TextStyle(fontSize: 12),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.volume_up, size: 18),
                        label: const Text('Écouter'),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          backgroundColor: const Color(0xFF2E7D32),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.share, size: 18),
                        label: const Text('Partager'),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          backgroundColor: Colors.grey[400],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
