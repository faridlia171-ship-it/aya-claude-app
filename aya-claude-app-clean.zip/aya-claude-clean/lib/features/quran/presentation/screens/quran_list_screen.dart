import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

// Placeholder for Coran data
final quranDataProvider = FutureProvider<List<SurahData>>((ref) async {
  // In real app, load from database
  return _getSampleSurahs();
});

class QuranListScreen extends ConsumerWidget {
  const QuranListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final surahsAsync = ref.watch(quranDataProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('القرآن الكريم'),
        elevation: 0,
      ),
      body: surahsAsync.when(
        data: (surahs) => _buildList(context, surahs),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, stack) => Center(child: Text('Error: $err')),
      ),
    );
  }

  Widget _buildList(BuildContext context, List<SurahData> surahs) {
    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: surahs.length,
      itemBuilder: (context, index) {
        final surah = surahs[index];
        return _SurahCard(
          surah: surah,
          onTap: () => context.go('/quran/surah/${surah.number}'),
        );
      },
    );
  }
}

class _SurahCard extends StatelessWidget {
  final SurahData surah;
  final VoidCallback onTap;

  const _SurahCard({
    required this.surah,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              // Surah Number
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: const Color(0xFF2E7D32),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    surah.number.toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),

              // Surah Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      surah.nameArabic,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      surah.englishName,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),

              // Verse Count & Type
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${surah.verseCount} verses',
                    style: const TextStyle(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    surah.revelationType,
                    style: TextStyle(
                      fontSize: 11,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              const Icon(Icons.arrow_forward_ios, size: 16),
            ],
          ),
        ),
      ),
    );
  }
}

// Data Models
class SurahData {
  final int number;
  final String nameArabic;
  final String englishName;
  final String revelationType;
  final int verseCount;

  SurahData({
    required this.number,
    required this.nameArabic,
    required this.englishName,
    required this.revelationType,
    required this.verseCount,
  });
}

// Sample Data
List<SurahData> _getSampleSurahs() {
  return [
    SurahData(
      number: 1,
      nameArabic: 'الفاتحة',
      englishName: 'Al-Fatiha',
      revelationType: 'Meccan',
      verseCount: 7,
    ),
    SurahData(
      number: 2,
      nameArabic: 'البقرة',
      englishName: 'Al-Baqarah',
      revelationType: 'Medinan',
      verseCount: 286,
    ),
    SurahData(
      number: 3,
      nameArabic: 'آل عمران',
      englishName: 'Al-Imran',
      revelationType: 'Medinan',
      verseCount: 200,
    ),
    SurahData(
      number: 4,
      nameArabic: 'النساء',
      englishName: 'An-Nisa',
      revelationType: 'Medinan',
      verseCount: 176,
    ),
    SurahData(
      number: 5,
      nameArabic: 'المائدة',
      englishName: 'Al-Maidah',
      revelationType: 'Medinan',
      verseCount: 120,
    ),
    // Add more surahs... (114 total)
  ];
}
