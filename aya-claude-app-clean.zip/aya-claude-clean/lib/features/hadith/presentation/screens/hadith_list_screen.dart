import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// ============== HADITH LIST SCREEN ==============

class HadithListScreen extends StatefulWidget {
  const HadithListScreen({Key? key}) : super(key: key);

  @override
  State<HadithListScreen> createState() => _HadithListScreenState();
}

class _HadithListScreenState extends State<HadithListScreen> {
  final collections = [
    {'name': 'Sahih Al-Bukhari', 'count': '7563', 'icon': '📖'},
    {'name': 'Sahih Muslim', 'count': '5852', 'icon': '📚'},
    {'name': 'Abu Dawud', 'count': '5274', 'icon': '📕'},
    {'name': 'At-Tirmidhi', 'count': '3956', 'icon': '📗'},
    {'name': 'An-Nasai', 'count': '5761', 'icon': '📔'},
    {'name': 'Ibn Majah', 'count': '4344', 'icon': '📙'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hadith Collections'),
        elevation: 0,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: collections.length,
        itemBuilder: (context, index) {
          final collection = collections[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              leading: Text(collection['icon']!, style: const TextStyle(fontSize: 28)),
              title: Text(collection['name']!),
              subtitle: Text('${collection['count']} hadiths'),
              trailing: const Icon(Icons.arrow_forward),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${collection['name']} - Bientôt disponible')),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// ============== SETTINGS SCREEN ==============

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _selectedLanguage = 'fr';
  bool _darkMode = false;
  bool _notifications = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Paramètres'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // App Info Section
            Container(
              padding: const EdgeInsets.all(20),
              color: Colors.grey[50],
              child: Column(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2E7D32),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.auto_awesome, color: Colors.white, size: 40),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Prof AYA la Queen',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Text(
                    'Version 1.0.0',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Display Settings
            _SettingsSection(
              title: 'Affichage',
              children: [
                _SettingsTile(
                  title: 'Langue',
                  subtitle: 'Français',
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Sélectionner la langue'),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: ['Français', 'English', 'العربية'].map((lang) {
                            return RadioListTile(
                              title: Text(lang),
                              value: lang,
                              groupValue: _selectedLanguage,
                              onChanged: (value) {
                                setState(() => _selectedLanguage = value ?? 'fr');
                                Navigator.pop(context);
                              },
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  },
                ),
                SwitchListTile(
                  title: const Text('Mode sombre'),
                  value: _darkMode,
                  onChanged: (value) => setState(() => _darkMode = value),
                ),
              ],
            ),

            // Content Settings
            _SettingsSection(
              title: 'Contenu',
              children: [
                _SettingsTile(
                  title: 'Télécharger le Coran complet',
                  subtitle: 'Utiliser hors-ligne',
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Téléchargement en cours...')),
                    );
                  },
                ),
                _SettingsTile(
                  title: 'Télécharger les Hadith',
                  subtitle: 'Collections complètes',
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Téléchargement en cours...')),
                    );
                  },
                ),
              ],
            ),

            // Notifications
            _SettingsSection(
              title: 'Notifications',
              children: [
                SwitchListTile(
                  title: const Text('Notifications'),
                  value: _notifications,
                  onChanged: (value) => setState(() => _notifications = value),
                ),
              ],
            ),

            // App Info
            _SettingsSection(
              title: 'À Propos',
              children: [
                _SettingsTile(
                  title: 'Conditions d\'utilisation',
                  onTap: () {},
                ),
                _SettingsTile(
                  title: 'Politique de confidentialité',
                  onTap: () {},
                ),
                _SettingsTile(
                  title: 'À propos de l\'app',
                  onTap: () {},
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Logout Button
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.withOpacity(0.1),
                  foregroundColor: Colors.red,
                  minimumSize: const Size.fromHeight(48),
                ),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('Confirmer'),
                      content: const Text('Êtes-vous sûr de vouloir réinitialiser l\'app?'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Annuler'),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: const Text('Réinitialiser'),
                        ),
                      ],
                    ),
                  );
                },
                child: const Text('Réinitialiser l\'app'),
              ),
            ),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SettingsSection({
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              letterSpacing: 0.5,
            ),
          ),
        ),
        ...children,
        Divider(color: Colors.grey[200]),
      ],
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.title,
    this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(title),
      subtitle: subtitle != null ? Text(subtitle!) : null,
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );
  }
}
