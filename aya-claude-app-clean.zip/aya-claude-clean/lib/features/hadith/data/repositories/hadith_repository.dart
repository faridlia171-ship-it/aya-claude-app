import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';

class HadithRepository {
  final Database database;

  HadithRepository({required this.database});

  // ============= LOAD HADITH DATA =============

  /// Charger les collections de Hadith
  Future<void> loadHadithCollections() async {
    try {
      final count = await database.rawQuery(
        'SELECT COUNT(*) as count FROM hadith_collections',
      );
      
      if ((count.first['count'] as int) > 0) {
        print('✅ Collections de Hadith déjà chargées');
        return;
      }

      print('📖 Chargement des collections de Hadith...');

      // Collections principales
      final collections = [
        {
          'name': 'Sahih Al-Bukhari',
          'author': 'Muhammad al-Bukhari',
          'total_hadiths': 7563,
          'description': 'Collection la plus authentique',
        },
        {
          'name': 'Sahih Muslim',
          'author': 'Muslim ibn al-Hajjaj',
          'total_hadiths': 5852,
          'description': 'Deuxième collection la plus authentique',
        },
        {
          'name': 'Abu Dawud',
          'author': 'Abu Dawud as-Sajistani',
          'total_hadiths': 5274,
          'description': 'Sunan Abu Dawud',
        },
        {
          'name': 'At-Tirmidhi',
          'author': 'Muhammad at-Tirmidhi',
          'total_hadiths': 3956,
          'description': 'Jami\' at-Tirmidhi',
        },
        {
          'name': 'An-Nasai',
          'author': 'Ahmad an-Nasai',
          'total_hadiths': 5761,
          'description': 'Sunan an-Nasai',
        },
        {
          'name': 'Ibn Majah',
          'author': 'Muhammad ibn Majah',
          'total_hadiths': 4344,
          'description': 'Sunan Ibn Majah',
        },
      ];

      for (var collection in collections) {
        await database.insert(
          'hadith_collections',
          collection,
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      print('✅ Collections de Hadith chargées: ${collections.length}');
    } catch (e) {
      print('❌ Erreur lors du chargement des collections: $e');
      rethrow;
    }
  }

  /// Charger les hadiths individuels depuis JSON
  /// Fichier: assets/hadith/hadith-abudawud.json (ou autre)
  Future<void> loadHadithsFromAssets(String collectionName) async {
    try {
      print('📚 Chargement des hadiths de $collectionName...');

      // Récupérer l'ID de la collection
      final collections = await database.query(
        'hadith_collections',
        where: 'name = ?',
        whereArgs: [collectionName],
      );

      if (collections.isEmpty) {
        print('⚠️  Collection non trouvée: $collectionName');
        return;
      }

      final collectionId = collections.first['id'];

      // Charger JSON selon la collection
      final filename = collectionName.toLowerCase().replaceAll(' ', '-');
      final jsonString = await rootBundle.loadString(
        'assets/hadith/$filename.json',
      );

      final hadithData = json.decode(jsonString) as Map<String, dynamic>;
      final hadiths = hadithData['hadiths'] as List? ?? [];

      for (var hadith in hadiths) {
        await database.insert(
          'hadiths',
          {
            'collection_id': collectionId,
            'hadith_number': hadith['number'] ?? 0,
            'chapter': hadith['chapter'] ?? '',
            'arabic_text': hadith['arabic_text'] ?? hadith['text'] ?? '',
            'english_translation': hadith['english'] ?? hadith['translation'] ?? '',
            'french_translation': hadith['french'] ?? '',
            'grade': hadith['grade'] ?? hadith['status'] ?? 'Unknown',
            'narrator': hadith['narrator'] ?? '',
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      print('✅ ${hadiths.length} hadiths chargés de $collectionName');
    } catch (e) {
      print('⚠️  Hadiths non trouvés pour $collectionName: $e');
    }
  }

  // ============= QUERIES =============

  /// Récupérer toutes les collections
  Future<List<Map<String, dynamic>>> getCollections() async {
    try {
      return await database.query('hadith_collections');
    } catch (e) {
      print('❌ Erreur getCollections: $e');
      rethrow;
    }
  }

  /// Récupérer les hadiths d'une collection
  Future<List<Map<String, dynamic>>> getHadithsByCollection(
    int collectionId, {
    int limit = 20,
    int offset = 0,
  }) async {
    try {
      return await database.query(
        'hadiths',
        where: 'collection_id = ?',
        whereArgs: [collectionId],
        orderBy: 'hadith_number ASC',
        limit: limit,
        offset: offset,
      );
    } catch (e) {
      print('❌ Erreur getHadithsByCollection: $e');
      rethrow;
    }
  }

  /// Chercher un hadith spécifique
  Future<Map<String, dynamic>?> getHadith(int hadithId) async {
    try {
      final result = await database.query(
        'hadiths',
        where: 'id = ?',
        whereArgs: [hadithId],
      );
      return result.isNotEmpty ? result.first : null;
    } catch (e) {
      print('❌ Erreur getHadith: $e');
      rethrow;
    }
  }

  /// Rechercher par texte
  Future<List<Map<String, dynamic>>> searchHadiths(String query) async {
    try {
      return await database.query(
        'hadiths',
        where: 'arabic_text LIKE ? OR english_translation LIKE ?',
        whereArgs: ['%$query%', '%$query%'],
      );
    } catch (e) {
      print('❌ Erreur searchHadiths: $e');
      rethrow;
    }
  }

  /// Ajouter un hadith aux favoris
  Future<void> addBookmark(int hadithId, String collectionName) async {
    try {
      await database.insert(
        'bookmarks',
        {
          'user_id': 'default_user',
          'content_type': 'hadith',
          'content_id': hadithId.toString(),
          'title': 'Hadith #$hadithId from $collectionName',
          'created_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
      print('✅ Hadith $hadithId ajouté aux favoris');
    } catch (e) {
      print('❌ Erreur addBookmark: $e');
    }
  }

  /// Récupérer les favoris Hadith
  Future<List<Map<String, dynamic>>> getBookmarks() async {
    try {
      return await database.query(
        'bookmarks',
        where: 'user_id = ? AND content_type = ?',
        whereArgs: ['default_user', 'hadith'],
        orderBy: 'created_at DESC',
      );
    } catch (e) {
      print('❌ Erreur getBookmarks: $e');
      rethrow;
    }
  }

  /// Statistiques des collections
  Future<Map<String, dynamic>> getCollectionStats() async {
    try {
      final collectionsCount = await database.rawQuery(
        'SELECT COUNT(*) as count FROM hadith_collections',
      );
      
      final hadithsCount = await database.rawQuery(
        'SELECT COUNT(*) as count FROM hadiths',
      );

      return {
        'collections': (collectionsCount.first['count'] as int),
        'hadiths': (hadithsCount.first['count'] as int),
      };
    } catch (e) {
      print('❌ Erreur getCollectionStats: $e');
      rethrow;
    }
  }
}
